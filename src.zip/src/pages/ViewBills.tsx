import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Receipt, Eye } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

interface Bill {
  id: string;
  billNo: string;
  date: string;
  customerName: string;
  customerPhone: string;
  paymentMode: string;
  items: any[];
  subtotal: number;
  cgst: number;
  sgst: number;
  total: number;
}

const ViewBills = () => {
  const [bills, setBills] = useState<Bill[]>([]);
  const [selectedBill, setSelectedBill] = useState<Bill | null>(null);

  useEffect(() => {
    const savedBills = JSON.parse(localStorage.getItem("bills") || "[]");
    setBills(savedBills);
  }, []);

  return (
    <div className="min-h-screen bg-background py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <Card>
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="bg-primary/10 rounded-lg p-3">
                <Receipt className="h-8 w-8 text-primary" />
              </div>
              <div>
                <CardTitle className="text-3xl">Bill History</CardTitle>
                <CardDescription>View all generated invoices</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {bills.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-muted-foreground text-lg">No bills generated yet</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Bill No</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Customer</TableHead>
                      <TableHead>Phone</TableHead>
                      <TableHead>Payment</TableHead>
                      <TableHead className="text-right">Total</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {bills.map((bill) => (
                      <TableRow key={bill.id}>
                        <TableCell className="font-medium">{bill.billNo}</TableCell>
                        <TableCell>{bill.date}</TableCell>
                        <TableCell>{bill.customerName}</TableCell>
                        <TableCell>{bill.customerPhone}</TableCell>
                        <TableCell>{bill.paymentMode}</TableCell>
                        <TableCell className="text-right font-semibold">
                          ₹{bill.total.toLocaleString()}
                        </TableCell>
                        <TableCell className="text-right">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => setSelectedBill(bill)}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Dialog open={!!selectedBill} onOpenChange={() => setSelectedBill(null)}>
        <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Bill Details - {selectedBill?.billNo}</DialogTitle>
            <DialogDescription>
              Customer: {selectedBill?.customerName} | Date: {selectedBill?.date}
            </DialogDescription>
          </DialogHeader>
          {selectedBill && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-muted-foreground">Phone:</span>{" "}
                  <span className="font-medium">{selectedBill.customerPhone}</span>
                </div>
                <div>
                  <span className="text-muted-foreground">Payment:</span>{" "}
                  <span className="font-medium">{selectedBill.paymentMode}</span>
                </div>
              </div>

              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Item</TableHead>
                    <TableHead>Qty</TableHead>
                    <TableHead>Purity</TableHead>
                    <TableHead>Weight</TableHead>
                    <TableHead className="text-right">Total</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {selectedBill.items.map((item, index) => {
                    const itemTotal =
                      (item.rate * item.grossWeight + item.labourCharge) * item.billQuantity;
                    return (
                      <TableRow key={index}>
                        <TableCell>{item.item}</TableCell>
                        <TableCell>{item.billQuantity}</TableCell>
                        <TableCell>{item.purity}</TableCell>
                        <TableCell>{item.grossWeight}g</TableCell>
                        <TableCell className="text-right">₹{itemTotal.toLocaleString()}</TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>

              <div className="space-y-2 text-right border-t pt-4">
                <div className="flex justify-end gap-4">
                  <span className="text-muted-foreground">Subtotal:</span>
                  <span>₹{selectedBill.subtotal.toLocaleString()}</span>
                </div>
                <div className="flex justify-end gap-4">
                  <span className="text-muted-foreground">CGST (1.5%):</span>
                  <span>₹{selectedBill.cgst.toLocaleString()}</span>
                </div>
                <div className="flex justify-end gap-4">
                  <span className="text-muted-foreground">SGST (1.5%):</span>
                  <span>₹{selectedBill.sgst.toLocaleString()}</span>
                </div>
                <div className="flex justify-end gap-4 text-xl font-bold">
                  <span>Total:</span>
                  <span className="text-primary">₹{selectedBill.total.toLocaleString()}</span>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ViewBills;
