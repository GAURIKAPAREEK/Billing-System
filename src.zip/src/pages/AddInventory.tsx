import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Package } from "lucide-react";

interface InventoryItem {
  id: string;
  item: string;
  rate: number;
  quantity: number;
  purity: string;
  grossWeight: number;
  labourCharge: number;
}

const AddInventory = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    item: "",
    rate: "",
    quantity: "",
    purity: "22K",
    grossWeight: "",
    labourCharge: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const newItem: InventoryItem = {
      id: Date.now().toString(),
      item: formData.item,
      rate: parseFloat(formData.rate),
      quantity: parseInt(formData.quantity),
      purity: formData.purity,
      grossWeight: parseFloat(formData.grossWeight),
      labourCharge: parseFloat(formData.labourCharge),
    };

    const existingItems = JSON.parse(localStorage.getItem("inventory") || "[]");
    existingItems.push(newItem);
    localStorage.setItem("inventory", JSON.stringify(existingItems));

    toast({
      title: "Success!",
      description: "Item added to VGL inventory",
    });

    setFormData({
      item: "",
      rate: "",
      quantity: "",
      purity: "22K",
      grossWeight: "",
      labourCharge: "",
    });
  };

  return (
    <div className="min-h-screen bg-background py-12">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <Card>
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="bg-primary/10 rounded-lg p-3">
                <Package className="h-8 w-8 text-primary" />
              </div>
              <div>
                <CardTitle className="text-3xl">Add Jewellery Item</CardTitle>
                <CardDescription>Add new items to VGL inventory</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="item">Item Name</Label>
                <Input
                  id="item"
                  value={formData.item}
                  onChange={(e) => setFormData({ ...formData, item: e.target.value })}
                  placeholder="e.g., Gold Necklace, Diamond Ring"
                  required
                />
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="rate">Rate (per gram)</Label>
                  <Input
                    id="rate"
                    type="number"
                    value={formData.rate}
                    onChange={(e) => setFormData({ ...formData, rate: e.target.value })}
                    placeholder="7000"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="quantity">Quantity</Label>
                  <Input
                    id="quantity"
                    type="number"
                    value={formData.quantity}
                    onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
                    placeholder="1"
                    required
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="purity">Purity</Label>
                  <Input
                    id="purity"
                    value={formData.purity}
                    onChange={(e) => setFormData({ ...formData, purity: e.target.value })}
                    placeholder="22K, 18K, etc."
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="grossWeight">Gross Weight (grams)</Label>
                  <Input
                    id="grossWeight"
                    type="number"
                    step="0.01"
                    value={formData.grossWeight}
                    onChange={(e) => setFormData({ ...formData, grossWeight: e.target.value })}
                    placeholder="10.5"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="labourCharge">Labour Charges (₹)</Label>
                <Input
                  id="labourCharge"
                  type="number"
                  step="0.01"
                  value={formData.labourCharge}
                  onChange={(e) => setFormData({ ...formData, labourCharge: e.target.value })}
                  placeholder="5000"
                  required
                />
              </div>

              <div className="flex gap-4">
                <Button type="submit" className="flex-1">
                  Add to Inventory
                </Button>
                <Button type="button" variant="outline" onClick={() => navigate("/view-inventory")}>
                  View Inventory
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default AddInventory;
