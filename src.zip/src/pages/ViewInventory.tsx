import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { List, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface InventoryItem {
  id: string;
  item: string;
  rate: number;
  quantity: number;
  purity: string;
  grossWeight: number;
  labourCharge: number;
}

const ViewInventory = () => {
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const { toast } = useToast();

  useEffect(() => {
    loadInventory();
  }, []);

  const loadInventory = () => {
    const items = JSON.parse(localStorage.getItem("inventory") || "[]");
    setInventory(items);
  };

  const deleteItem = (id: string) => {
    const updatedInventory = inventory.filter((item) => item.id !== id);
    localStorage.setItem("inventory", JSON.stringify(updatedInventory));
    setInventory(updatedInventory);
    toast({
      title: "Item Deleted",
      description: "Item removed from inventory",
    });
  };

  return (
    <div className="min-h-screen bg-background py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <Card>
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="bg-primary/10 rounded-lg p-3">
                <List className="h-8 w-8 text-primary" />
              </div>
              <div>
                <CardTitle className="text-3xl">Inventory List</CardTitle>
                <CardDescription>View all jewellery items in stock</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {inventory.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-muted-foreground text-lg">No items in inventory</p>
                <p className="text-sm text-muted-foreground mt-2">Add items to get started</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Item Name</TableHead>
                      <TableHead>Purity</TableHead>
                      <TableHead>Weight (g)</TableHead>
                      <TableHead>Rate (₹/g)</TableHead>
                      <TableHead>Labour (₹)</TableHead>
                      <TableHead>Quantity</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {inventory.map((item) => (
                      <TableRow key={item.id}>
                        <TableCell className="font-medium">{item.item}</TableCell>
                        <TableCell>{item.purity}</TableCell>
                        <TableCell>{item.grossWeight}</TableCell>
                        <TableCell>₹{item.rate.toLocaleString()}</TableCell>
                        <TableCell>₹{item.labourCharge.toLocaleString()}</TableCell>
                        <TableCell>{item.quantity}</TableCell>
                        <TableCell className="text-right">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => deleteItem(item.id)}
                            className="text-destructive hover:text-destructive"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default ViewInventory;
