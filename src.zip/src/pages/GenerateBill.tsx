import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { FileText, Plus, Trash2 } from "lucide-react";

interface InventoryItem {
  id: string;
  item: string;
  rate: number;
  quantity: number;
  purity: string;
  grossWeight: number;
  labourCharge: number;
}

interface BillItem extends InventoryItem {
  billQuantity: number;
}

const GenerateBill = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [selectedItem, setSelectedItem] = useState<string>("");
  const [billQuantity, setBillQuantity] = useState<string>("1");
  const [billItems, setBillItems] = useState<BillItem[]>([]);
  const [customerName, setCustomerName] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [paymentMode, setPaymentMode] = useState("Cash");

  useEffect(() => {
    const items = JSON.parse(localStorage.getItem("inventory") || "[]");
    setInventory(items);
  }, []);

  const addItemToBill = () => {
    const item = inventory.find((i) => i.id === selectedItem);
    if (!item) return;

    const qty = parseInt(billQuantity);
    if (qty > item.quantity) {
      toast({
        title: "Error",
        description: "Not enough stock available",
        variant: "destructive",
      });
      return;
    }

    setBillItems([...billItems, { ...item, billQuantity: qty }]);
    setSelectedItem("");
    setBillQuantity("1");
  };

  const removeItemFromBill = (index: number) => {
    setBillItems(billItems.filter((_, i) => i !== index));
  };

  const calculateTotal = () => {
    const subtotal = billItems.reduce((sum, item) => {
      const itemTotal = item.rate * item.grossWeight + item.labourCharge;
      return sum + itemTotal * item.billQuantity;
    }, 0);

    const cgst = subtotal * 0.015;
    const sgst = subtotal * 0.015;
    const total = subtotal + cgst + sgst;

    return { subtotal, cgst, sgst, total };
  };

  const generateBill = () => {
    if (!customerName || !customerPhone || billItems.length === 0) {
      toast({
        title: "Error",
        description: "Please fill all details and add items",
        variant: "destructive",
      });
      return;
    }

    const { subtotal, cgst, sgst, total } = calculateTotal();
    const billNo = (JSON.parse(localStorage.getItem("billCounter") || "100")) + 1;
    localStorage.setItem("billCounter", JSON.stringify(billNo));

    const bill = {
      id: Date.now().toString(),
      billNo: `VGL${billNo}`,
      date: new Date().toLocaleDateString(),
      customerName,
      customerPhone,
      paymentMode,
      items: billItems,
      subtotal,
      cgst,
      sgst,
      total,
    };

    const bills = JSON.parse(localStorage.getItem("bills") || "[]");
    bills.push(bill);
    localStorage.setItem("bills", JSON.stringify(bills));

    // Update inventory
    const updatedInventory = inventory.map((invItem) => {
      const billItem = billItems.find((bi) => bi.id === invItem.id);
      if (billItem) {
        return { ...invItem, quantity: invItem.quantity - billItem.billQuantity };
      }
      return invItem;
    });
    localStorage.setItem("inventory", JSON.stringify(updatedInventory));

    toast({
      title: "Success!",
      description: `Bill ${bill.billNo} generated successfully`,
    });

    navigate("/view-bills");
  };

  const { subtotal, cgst, sgst, total } = calculateTotal();

  return (
    <div className="min-h-screen bg-background py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <Card>
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="bg-primary/10 rounded-lg p-3">
                <FileText className="h-8 w-8 text-primary" />
              </div>
              <div>
                <CardTitle className="text-3xl">Generate Bill</CardTitle>
                <CardDescription>Create invoice for customer purchase</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>Customer Name</Label>
                <Input
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="Enter name"
                />
              </div>
              <div className="space-y-2">
                <Label>Phone Number</Label>
                <Input
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  placeholder="Enter phone"
                />
              </div>
              <div className="space-y-2">
                <Label>Payment Mode</Label>
                <Select value={paymentMode} onValueChange={setPaymentMode}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Cash">Cash</SelectItem>
                    <SelectItem value="Card">Card</SelectItem>
                    <SelectItem value="UPI">UPI</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="border-t pt-6">
              <h3 className="text-lg font-semibold mb-4">Add Items to Bill</h3>
              <div className="flex gap-4">
                <Select value={selectedItem} onValueChange={setSelectedItem}>
                  <SelectTrigger className="flex-1">
                    <SelectValue placeholder="Select item" />
                  </SelectTrigger>
                  <SelectContent>
                    {inventory.map((item) => (
                      <SelectItem key={item.id} value={item.id}>
                        {item.item} - {item.purity} ({item.quantity} available)
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Input
                  type="number"
                  value={billQuantity}
                  onChange={(e) => setBillQuantity(e.target.value)}
                  placeholder="Qty"
                  className="w-24"
                />
                <Button onClick={addItemToBill} disabled={!selectedItem}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add
                </Button>
              </div>
            </div>

            {billItems.length > 0 && (
              <div className="border-t pt-6">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Item</TableHead>
                      <TableHead>Qty</TableHead>
                      <TableHead>Weight</TableHead>
                      <TableHead>Rate</TableHead>
                      <TableHead>Labour</TableHead>
                      <TableHead className="text-right">Total</TableHead>
                      <TableHead></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {billItems.map((item, index) => {
                      const itemTotal = (item.rate * item.grossWeight + item.labourCharge) * item.billQuantity;
                      return (
                        <TableRow key={index}>
                          <TableCell>{item.item}</TableCell>
                          <TableCell>{item.billQuantity}</TableCell>
                          <TableCell>{item.grossWeight}g</TableCell>
                          <TableCell>₹{item.rate}</TableCell>
                          <TableCell>₹{item.labourCharge}</TableCell>
                          <TableCell className="text-right">₹{itemTotal.toLocaleString()}</TableCell>
                          <TableCell>
                            <Button variant="ghost" size="icon" onClick={() => removeItemFromBill(index)}>
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>

                <div className="mt-6 space-y-2 text-right">
                  <div className="flex justify-end gap-4">
                    <span className="text-muted-foreground">Subtotal:</span>
                    <span className="font-semibold">₹{subtotal.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-end gap-4">
                    <span className="text-muted-foreground">CGST (1.5%):</span>
                    <span>₹{cgst.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-end gap-4">
                    <span className="text-muted-foreground">SGST (1.5%):</span>
                    <span>₹{sgst.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-end gap-4 text-xl font-bold border-t pt-2">
                    <span>Total:</span>
                    <span className="text-primary">₹{total.toLocaleString()}</span>
                  </div>
                </div>

                <div className="mt-6 flex justify-end">
                  <Button onClick={generateBill} size="lg">
                    Generate Bill
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default GenerateBill;
