import { Link } from "react-router-dom";
import { Package, FileText, TrendingUp, Receipt, Users, CreditCard } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const Dashboard = () => {
  const features = [
    {
      icon: TrendingUp,
      title: "Stock Management",
      description: "Track purity, weight, and labour charges",
    },
    {
      icon: Receipt,
      title: "Professional Invoices",
      description: "Auto-calculated taxes (CGST + SGST)",
    },
    {
      icon: FileText,
      title: "Bill History Tracking",
      description: "View all generated invoices",
    },
    {
      icon: Package,
      title: "Inventory Control",
      description: "Real-time stock updates",
    },
    {
      icon: Users,
      title: "Customer Records",
      description: "Maintain customer details and purchase history",
    },
    {
      icon: CreditCard,
      title: "Multiple Payment Modes",
      description: "Support for Cash, Card, and UPI payments",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-16">
          <h1 className="text-5xl font-bold text-primary mb-4">
            Welcome to Billing System
          </h1>
          <p className="text-xl text-muted-foreground">
            Track stock and generate professional invoices
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-16">
          <Card className="border-primary/20 hover:border-primary/40 transition-colors">
            <CardHeader>
              <div className="bg-primary/10 rounded-lg w-fit p-3 mb-2">
                <Package className="h-8 w-8 text-primary" />
              </div>
              <CardTitle className="text-2xl">Add Inventory</CardTitle>
              <CardDescription className="text-base">
                Add new jewellery items to stock
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link to="/add-inventory">
                <Button className="w-full" size="lg">
                  Get Started
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="border-primary/20 hover:border-primary/40 transition-colors">
            <CardHeader>
              <div className="bg-primary/10 rounded-lg w-fit p-3 mb-2">
                <FileText className="h-8 w-8 text-primary" />
              </div>
              <CardTitle className="text-2xl">Generate Bill</CardTitle>
              <CardDescription className="text-base">
                Create invoice for customer purchase
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link to="/generate-bill">
                <Button className="w-full" size="lg">
                  Get Started
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>

        <div className="border-t border-border pt-12">
          <div className="flex items-center gap-2 mb-8">
            <TrendingUp className="h-6 w-6 text-primary" />
            <h2 className="text-3xl font-bold">System Features</h2>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Card key={index} className="border-border hover:border-primary/40 transition-colors">
                  <CardHeader>
                    <div className="flex items-start gap-3">
                      <div className="bg-primary/10 rounded-lg p-2">
                        <Icon className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <CardTitle className="text-lg mb-1">{feature.title}</CardTitle>
                        <CardDescription>{feature.description}</CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                </Card>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
